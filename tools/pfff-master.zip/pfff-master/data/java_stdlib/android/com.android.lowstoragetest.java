package com.android.lowstoragetest;
class LowStorageTest {
  int mStartListener;
  int fillUpDone;
  int mBlockSize;
  int WAIT_FOR_SYSTEM_UPDATE;
  int BYTE_SIZE;
  int NO_OF_BLOCKS_TO_FILL;
  int WAIT_FOR_FINISH;
  int TAG;
}
