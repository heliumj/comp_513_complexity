package com.android.smoketest;
class SmokeTestRunner {
  int SUITE_NAME;
}
class SmokeTestActivity {
}
class ProcessErrorsTest {
  class ProcessError {
    int info;
  }
  int mAsyncErrors;
  int mPackageManager;
  int mActivityManager;
  int mHomeIntent;
  int TAG;
}
