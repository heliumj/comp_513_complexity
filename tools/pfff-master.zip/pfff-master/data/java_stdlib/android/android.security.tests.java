package android.security.tests;
class SystemKeyStoreTest {
  int mSysKeyStore;
  int keyName2;
  int keyName;
}
class KeyStoreTestRunner {
}
class KeyStoreTest {
  int PRIVKEY_BYTES;
  int mKeyStore;
  int TEST_DATA;
  int TEST_I18N_VALUE;
  int TEST_I18N_KEY;
  int TEST_KEYVALUE;
  int TEST_KEYNAME2;
  int TEST_KEYNAME1;
  int TEST_KEYNAME;
  int TEST_PASSWD2;
  int TEST_PASSWD;
}
