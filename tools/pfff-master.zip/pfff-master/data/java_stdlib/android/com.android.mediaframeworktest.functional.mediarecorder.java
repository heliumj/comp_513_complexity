package com.android.mediaframeworktest.functional.mediarecorder;
class MediaRecorderTest {
  int mCamera;
  int mContext;
  int CAMERA_ID;
  int MIN_VIDEO_FPS;
  int mRecorder;
  int mSurfaceHolder;
  int mOutputVideoHeight;
  int mOutputVideoWidth;
  int mOutputDuration;
  int TAG;
}
