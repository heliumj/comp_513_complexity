package com.android.mediaframeworktest.functional.mediaplayback;
class MediaPlayerApiTest {
  int mContext;
  int isWMVEnable;
  int isWMAEnable;
  int TAG;
  int duratoinWithinTolerence;
}
