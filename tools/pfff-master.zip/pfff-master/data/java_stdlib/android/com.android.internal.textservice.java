package com.android.internal.textservice;
class ITextServicesManager_Stub_Delegate {
  class FakeTextServicesManager {
  }
}
