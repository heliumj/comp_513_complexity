package android.test.mock;
class MockResources {
}
class MockPackageManager {
}
class MockIContentProvider {
}
class MockDialogInterface {
}
class MockCursor {
}
class MockContext {
}
class MockContentResolver {
  int mProviders;
}
class MockContentProvider {
  int mIContentProvider;
  class InversionIContentProvider {
  }
}
class MockApplication {
}
