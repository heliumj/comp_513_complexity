package android.widget.layout.table;
class WeightTest {
  int mRow;
  int mCell3;
  int mCell2;
  int mCell1;
}
class Weight {
}
class VerticalGravityTest {
  int mBottom;
  int mCenter;
  int mTop;
  int mReference3;
  int mReference2;
  int mReference1;
}
class VerticalGravity {
}
class HorizontalGravityTest {
  int mLeft;
  int mBottomRight;
  int mCenter;
  int mReference;
}
class HorizontalGravity {
}
class FixedWidthTest {
  int mNonFixedWidth;
  int mFixedHeight;
  int mFixedWidth;
}
class FixedWidth {
}
class CellSpanTest {
  int mSpan;
  int mCellThenSpan;
  int mSpanThenCell;
  int mC;
  int mB;
  int mA;
}
class CellSpan {
}
class AddColumnTest {
  int mTable;
  int mAddRow;
}
class AddColumn {
}
