package java.nio.charset.spi;
class CharsetProvider {
}
