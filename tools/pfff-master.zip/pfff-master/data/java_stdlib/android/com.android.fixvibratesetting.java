package com.android.fixvibratesetting;
class FixVibrateSetting {
  int mTest;
  int mUnfix;
  int mFix;
  int mCurrentSetting;
  int mNotificationManager;
  int mAudioManager;
}
