package com.android.internal.os.storage;
class ExternalStorageFormatter {
  int mStorageListener;
  int mAlwaysReset;
  int mFactoryReset;
  int mProgressDialog;
  int mWakeLock;
  int mStorageManager;
  int mMountService;
  int COMPONENT_NAME;
  int mStorageVolume;
  int EXTRA_ALWAYS_RESET;
  int FORMAT_AND_FACTORY_RESET;
  int FORMAT_ONLY;
  int TAG;
}
