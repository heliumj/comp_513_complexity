package com.android.tests.dataidle;
class DataIdleTest {
  int INSTRUMENTATION_IN_PROGRESS;
  int LOG_TAG;
  int mStatsService;
  int mTelephonyManager;
}
