package android.debug;
class JNITest {
}
