package com.android.tests.appwidgetprovider;
class TestAppWidgetProvider {
  int TAG;
}
