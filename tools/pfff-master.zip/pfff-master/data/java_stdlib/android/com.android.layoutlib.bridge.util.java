package com.android.layoutlib.bridge.util;
class SparseWeakArray {
  int mSize;
  int mValues;
  int mKeys;
  int mGarbage;
  int DELETED;
  int DELETED_REF;
}
class DynamicIdMap {
  int mDynamicSeed;
  int mRevDynamicIds;
  int mDynamicIds;
}
class Debug {
  int DEBUG;
}
