package com.android.frameworks.telephonytests;
class TelephonyMockRilTestRunner {
  int mMockRilChannel;
}
