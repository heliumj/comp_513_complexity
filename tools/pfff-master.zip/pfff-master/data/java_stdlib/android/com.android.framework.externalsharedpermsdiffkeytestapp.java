package com.android.framework.externalsharedpermsdiffkeytestapp;
class ExternalSharedPermsDiffKeyTest {
  int REQUEST_ENABLE_BT;
}
