package com.android.fountain_v11;
class Fountain_v11 {
  int mView;
  int LOG_ENABLED;
  int DEBUG;
  int LOG_TAG;
}
class FountainView {
  int mRender;
  int mRS;
}
class FountainRS {
  int holdingColor;
  int mScript;
  int mRS;
  int mRes;
  int PART_COUNT;
}
