package android.media.effect.effects;
class VignetteEffect {
}
class TintEffect {
}
class StraightenEffect {
}
class SharpenEffect {
}
class SepiaEffect {
}
class SaturateEffect {
}
class RotateEffect {
}
class RedEyeEffect {
}
class PosterizeEffect {
}
class NegativeEffect {
}
class LomoishEffect {
}
class IdentityEffect {
}
class GrayscaleEffect {
}
class GrainEffect {
}
class FlipEffect {
}
class FisheyeEffect {
}
class FillLightEffect {
}
class DuotoneEffect {
}
class DocumentaryEffect {
}
class CrossProcessEffect {
}
class CropEffect {
}
class ContrastEffect {
}
class ColorTemperatureEffect {
}
class BrightnessEffect {
}
class BlackWhiteEffect {
}
class BitmapOverlayEffect {
}
class BackDropperEffect {
  int mLearningListener;
  int mEffectListener;
  int mGraphDefinition;
}
class AutoFixEffect {
}
