package android.server.search;
class Searchables {
  int GLOBAL_SEARCH_RANKER;
  int ENHANCED_GOOGLE_SEARCH_COMPONENT_NAME;
  int GOOGLE_SEARCH_COMPONENT_NAME;
  int mWebSearchActivity;
  int mCurrentGlobalSearchActivity;
  int mGlobalSearchActivities;
  int mSearchablesInGlobalSearchList;
  int mSearchablesList;
  int mSearchablesMap;
  int mContext;
  int MD_SEARCHABLE_SYSTEM_SEARCH;
  int MD_LABEL_DEFAULT_SEARCHABLE;
  int LOG_TAG;
}
class SearchManagerService {
  class GlobalSearchProviderObserver {
    int mResolver;
  }
  class MyPackageMonitor {
  }
  class BootCompletedReceiver {
  }
  int mGlobalSearchObserver;
  int mSearchables;
  int mContext;
  int TAG;
}
