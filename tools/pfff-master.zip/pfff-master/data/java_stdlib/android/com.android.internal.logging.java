package com.android.internal.logging;
class AndroidHandler {
  int THE_FORMATTER;
}
class AndroidConfig {
}
