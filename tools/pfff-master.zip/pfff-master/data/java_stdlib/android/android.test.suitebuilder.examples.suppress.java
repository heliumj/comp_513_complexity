package android.test.suitebuilder.examples.suppress;
class SuppressedTest {
}
class PartiallySuppressedTest {
}
