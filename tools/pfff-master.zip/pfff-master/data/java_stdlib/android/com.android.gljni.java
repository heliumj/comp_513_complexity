package com.android.gljni;
class GLJNIView {
  class Renderer {
    int TAG;
  }
}
class GLJNILib {
}
class GLJNIActivity {
  int mView;
}
