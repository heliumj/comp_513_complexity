package com.android.common.io;
class MoreCloseables {
}
