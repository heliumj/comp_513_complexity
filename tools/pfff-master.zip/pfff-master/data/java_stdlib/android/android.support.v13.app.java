package android.support.v13.app;
class FragmentStatePagerAdapter {
  int mCurrentPrimaryItem;
  int mFragments;
  int mSavedState;
  int mCurTransaction;
  int mFragmentManager;
  int DEBUG;
  int TAG;
}
class FragmentPagerAdapter {
  int mCurrentPrimaryItem;
  int mCurTransaction;
  int mFragmentManager;
  int DEBUG;
  int TAG;
}
class FragmentCompatICSMR1 {
}
class FragmentCompatICS {
}
class FragmentCompat {
  int IMPL;
  class ICSMR1FragmentCompatImpl {
  }
  class ICSFragmentCompatImpl {
  }
  class BaseFragmentCompatImpl {
  }
  class FragmentCompatImpl {
  }
}
