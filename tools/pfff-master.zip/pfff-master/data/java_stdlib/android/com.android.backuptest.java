package com.android.backuptest;
class BackupTestAgent {
}
class BackupTestActivity {
  class Test {
    int name;
  }
  int mTests;
  int sBm;
  int FILE_NAME;
  int PREF_KEY;
  int PREF_GROUP_SETTINGS;
  int TAG;
}
