package com.android.layoutlib.bridge.bars;
class TitleBar {
  int mTextView;
}
class TabletSystemBar {
}
class PhoneSystemBar {
}
class FakeActionBar {
  int mTextView;
}
class CustomBar {
}
