package com.android.gl2java;
class GL2JavaView {
  class Renderer {
    int mvPositionHandle;
    int mProgram;
    int mFragmentShader;
    int mVertexShader;
    int mTriangleVertices;
    int mTriangleVerticesData;
  }
  int TAG;
}
class GL2JavaActivity {
  int mView;
}
