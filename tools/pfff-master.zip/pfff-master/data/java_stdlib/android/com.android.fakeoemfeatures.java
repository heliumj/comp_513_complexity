package com.android.fakeoemfeatures;
class FakeView {
  int mRandom;
  int mPaint;
  int mHandler;
  int MSG_TICK;
  int TICK_DELAY;
}
class FakeCoreService3 {
}
class FakeCoreService2 {
}
class FakeCoreService {
  int mBinder;
}
class FakeBackgroundService {
  int mHandler;
  int MSG_TICK;
  int TICK_DELAY;
  int mRandom;
  int mAllocs;
}
class FakeApp {
  int mServiceConnection3;
  int mServiceConnection2;
  int mServiceConnection;
  int mHandler;
  int MSG_TICK;
  int TICK_DELAY;
  int PAGE_SIZE;
  int mStuffing;
  int STUFFING_SIZE_INTS;
  int STUFFING_SIZE_BYTES;
}
