package com.android.test;
class TestView {
  class Renderer {
    int TAG;
  }
}
class TestActivity {
  int mRunnable;
  int PAUSE_DELAY;
  int mCount;
  int mToggle;
  int mView;
  int TAG;
}
