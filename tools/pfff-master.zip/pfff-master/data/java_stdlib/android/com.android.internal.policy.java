package com.android.internal.policy;
class PolicyManager {
}
class IPolicy {
}
