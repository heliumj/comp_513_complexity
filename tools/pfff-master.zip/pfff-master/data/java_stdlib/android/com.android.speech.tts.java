package com.android.speech.tts;
class TextToSpeechTests {
  class CountDownBehaviour {
  }
  int mTts;
  int MOCK_PACKAGE;
  int MOCK_ENGINE;
}
class MockableTextToSpeechService {
  class IDelegate {
  }
  int sDelegate;
}
class MockableCheckVoiceData {
}
