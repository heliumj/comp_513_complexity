package com.android.rs.sample;
class SampleRSActivity {
  int mScript;
  int mCityAlloc;
  int mTwoByTwoAlloc;
  int mRS;
  int mBenchmarkResult;
  int mBitmapCity;
  int mBitmapTwoByTwo;
  int TAG;
  class TextureViewUpdater {
    int mSampler;
    int mOutPixelsAllocation;
  }
}
