package com.android.internal.telephony.ims;
class IsimUiccRecords {
  class EfIsimDomainLoaded {
  }
  class EfIsimImpuLoaded {
  }
  class EfIsimImpiLoaded {
  }
  int TAG_ISIM_VALUE;
  int mIsimImpu;
  int mIsimDomain;
  int mIsimImpi;
  int DUMP_RECORDS;
  int DBG;
  int LOG_TAG;
}
class IsimRecords {
}
