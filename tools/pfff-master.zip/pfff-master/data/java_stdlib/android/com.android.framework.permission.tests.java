package com.android.framework.permission.tests;
class WindowManagerPermissionTests {
  int mWm;
}
class VibratorServicePermissionTest {
  int mVibratorService;
}
class SmsManagerPermissionTest {
  int SRC_NUMBER;
  int DEST_NUMBER;
  int DEST_PORT;
  int MSG_CONTENTS;
}
class ServiceManagerPermissionTests {
}
class PmPermissionsTests {
  int mPkgName;
  int mPm;
}
class ActivityManagerPermissionTests {
  int mAm;
}
