package com.android.vpndialogs;
class ManageDialog {
  int mHandler;
  int mDataRowsHidden;
  int mDataReceived;
  int mDataTransmitted;
  int mDuration;
  int mService;
  int mConfig;
  int TAG;
}
class ConfirmDialog {
  int mButton;
  int mService;
  int mPackage;
  int TAG;
}
