package com.android.framework.externallocpermsfltestapp;
class ExternalLocPermsFLTestAppActivity {
}
