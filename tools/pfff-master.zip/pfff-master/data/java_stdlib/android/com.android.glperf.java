package com.android.glperf;
class GLPerfView {
  class Renderer {
  }
  class ConfigChooser {
    int mValue;
    int mStencilSize;
    int mDepthSize;
    int mAlphaSize;
    int mBlueSize;
    int mGreenSize;
    int mRedSize;
    int s_configAttribs2;
    int EGL_OPENGL_ES2_BIT;
  }
  class ContextFactory {
    int EGL_CONTEXT_CLIENT_VERSION;
  }
  int TAG;
}
class GLPerfLib {
}
class GLPerfActivity {
  int mView;
}
