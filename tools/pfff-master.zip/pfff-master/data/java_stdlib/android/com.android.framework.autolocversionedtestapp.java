package com.android.framework.autolocversionedtestapp;
class AutoLocVersionedTestAppActivity {
}
