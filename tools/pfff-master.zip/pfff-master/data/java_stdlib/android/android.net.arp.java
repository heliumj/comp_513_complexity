package android.net.arp;
class ArpPeer {
  int TAG;
  int IPV4_LENGTH;
  int MAC_ADDR_LENGTH;
  int ARP_LENGTH;
  int ETHERNET_TYPE;
  int MAX_LENGTH;
  int L2_BROADCAST;
  int mSocket;
  int mPeer;
  int mMyMac;
  int mMyAddr;
  int mInterfaceName;
}
