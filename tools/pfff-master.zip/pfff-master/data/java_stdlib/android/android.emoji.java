package android.emoji;
class EmojiFactory {
  int mCache;
  int mName;
  int mNativeEmojiFactory;
  class CustomLinkedHashMap {
  }
  int sCacheSize;
}
