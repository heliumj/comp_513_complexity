package com.android.framework.versatiletestapp;
class VersatileTestAppActivity {
}
