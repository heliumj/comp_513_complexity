package android.test.suitebuilder.examples.simple;
class SimpleTest {
}
class AnotherSimpleTest {
}
