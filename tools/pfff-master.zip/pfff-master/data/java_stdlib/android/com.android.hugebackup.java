package com.android.hugebackup;
class HugeBackupActivity {
  int mBackupManager;
  int mDataFile;
  int mAddTomatoCheckbox;
  int mAddMayoCheckbox;
  int mFillingGroup;
  int DATA_FILE_NAME;
  int sDataLock;
  int TAG;
}
class HugeAgent {
  int mDataFile;
  int mFilling;
  int mAddTomato;
  int mAddMayo;
  int HUGE_DATA_KEY;
  int APP_DATA_KEY;
  int AGENT_VERSION;
}
