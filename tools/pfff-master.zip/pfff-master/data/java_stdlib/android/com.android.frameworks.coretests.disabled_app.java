package com.android.frameworks.coretests.disabled_app;
class EnabledActivity {
}
