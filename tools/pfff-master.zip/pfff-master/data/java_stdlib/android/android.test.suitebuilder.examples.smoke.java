package android.test.suitebuilder.examples.smoke;
class SmokeTest {
}
class NonSmokeTest {
}
