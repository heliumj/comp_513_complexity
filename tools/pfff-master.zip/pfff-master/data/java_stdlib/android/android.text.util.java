package android.text.util;
class Rfc822Tokenizer {
}
class Rfc822Token {
  int mComment;
  int mAddress;
  int mName;
}
class LinkifyTest {
}
class LinkSpec {
  int end;
  int start;
  int url;
}
class Linkify {
  class TransformFilter {
  }
  class MatchFilter {
  }
  int sPhoneNumberTransformFilter;
  int sPhoneNumberMatchFilter;
  int sUrlMatchFilter;
  int PHONE_NUMBER_MINIMUM_DIGITS;
  int ALL;
  int MAP_ADDRESSES;
  int PHONE_NUMBERS;
  int EMAIL_ADDRESSES;
  int WEB_URLS;
}
