package com.android.connectivitymanagertest.stress;
class WifiStressTest {
  int mWifiOnlyFlag;
  int mOutputWriter;
  int mRunner;
  int mPassword;
  int mSsid;
  int mScanIterations;
  int mWifiSleepTime;
  int mReconnectIterations;
  int mAct;
  int OUTPUT_FILE;
  int WIFI_SHUTDOWN_DELAY;
  int WIFI_IDLE_MS;
  int TAG;
}
class WifiApStress {
  int mWifiOnlyFlag;
  int mLastIteration;
  int mOutputWriter;
  int iterations;
  int mAct;
  int OUTPUT_FILE;
  int PASSWD;
  int NETWORK_ID;
  int TAG;
}
