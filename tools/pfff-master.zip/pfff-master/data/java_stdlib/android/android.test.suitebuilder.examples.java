package android.test.suitebuilder.examples;
class OuterTest {
}
