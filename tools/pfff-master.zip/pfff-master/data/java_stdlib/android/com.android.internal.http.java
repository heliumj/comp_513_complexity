package com.android.internal.http;
class HttpDateTime {
  class TimeOfDay {
    int second;
    int minute;
    int hour;
  }
  int HTTP_DATE_ANSIC_PATTERN;
  int HTTP_DATE_RFC_PATTERN;
  int HTTP_DATE_ANSIC_REGEXP;
  int HTTP_DATE_RFC_REGEXP;
}
