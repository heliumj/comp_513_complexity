package com.android.gldual;
class Triangle {
  int mIndexBuffer;
  int mFVertexBuffer;
  int VERTS;
}
class TriangleRenderer {
  int mTriangle;
}
class GLDualLib {
}
class GLDualGL2View {
  class Renderer {
  }
  class ConfigChooser {
    int mValue;
    int mStencilSize;
    int mDepthSize;
    int mAlphaSize;
    int mBlueSize;
    int mGreenSize;
    int mRedSize;
    int s_configAttribs2;
    int EGL_OPENGL_ES2_BIT;
  }
  class ContextFactory {
    int EGL_CONTEXT_CLIENT_VERSION;
  }
  int TAG;
}
class GLDualActivity {
  int mGL2View;
  int mGLView;
}
