package android.view.menu;
class MenuWith1ItemTest {
  int mActivity;
}
class MenuWith1Item {
  int mButton;
}
class MenuScenario {
  class Params {
    int itemTitles;
    int listenForClicks;
    int numItems;
    int shouldShowMenu;
  }
  int mWasItemClicked;
  int mItems;
  int mMenu;
  int mParams;
}
class MenuLayoutPortraitTest {
  int mActivity;
  int SHORT_TITLE;
  int LONG_TITLE;
}
class MenuLayoutPortrait {
}
class MenuLayoutLandscapeTest {
  int mActivity;
  int SHORT_TITLE;
  int LONG_TITLE;
}
class MenuLayoutLandscape {
}
class MenuLayout {
  int mButton;
  int SHORT_TITLE;
  int LONG_TITLE;
}
