package com.android.tools.layoutlib.create.dataclass;
class OuterClass_InnerClass_Delegate {
}
class OuterClass_Delegate {
}
class OuterClass {
  class InnerClass {
  }
  int mOuterValue;
}
class ClassWithNative_Delegate {
}
class ClassWithNative {
}
